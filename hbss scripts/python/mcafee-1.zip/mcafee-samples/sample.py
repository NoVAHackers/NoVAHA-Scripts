# Copyright (C) 2010 McAfee, Inc.  All Rights Reserved.

#
# This sample script demonstrates how to script commands
# against your server. It runs the core.help() command
# processes the output and prints a list of objects
# available for importing into your script.  Each significant
# section of code is documented and additional comments
# include various other usage scenerios.  
#

#
# The following two lines are boilerplate code that all 
# scripts you write will need to include before trying
# to execute a mcafee remote command
#
# Generic usage is:
# >>> mc = mcafee.client('yourservername', 'port', 'username', 'password', 'protocol', 'output', 'display')
#
# where protocol is one of ('https') and
# output is one of ('terse','verbose','json','xml')
# display is one of (0,1)
# If you don't specify either the defaults are 'https' and 'json'
#
import mcafee
mc = mcafee.client('myeposerver','8443','usr','pwd')

#
# The help for a command is available by using the mcafee.help() function.
# This is one of few places where where usage is not pythonic.  This was chosen
# over using the built-in help() because an extra hit to the server was
# required even when NOT requesting help, ie calling the command.
#
# Example: 
# >>> import mcafee
# >>> mc = mcafee.client('myeposerver','8443','usr','pwd')
# >>> mc.help('core.listUsers')

#
# Here's the meat of the script.  It calls the core.help() command, processes 
# the result and returns the list of prefixes that are available for importing
# into your script.
#
# 
# core.help() returns a list of dictionaries
# Each dictionary contains a single key called 'help'
# The value of 'help' is the help for the command in this format:
# 
# prefix.commandName [argument [arguments...] ] description of this command
#



cmds = mc.core.help()
prefixes = []
for cmd in cmds:
    prefix = cmd['help'].split('.')[0]
    try:
       prefixes.index(prefix)
    except:
       prefixes.append(prefix)
       
for prefix in prefixes: print prefix


#
# You could also do a dir for similar results:
#
# >>> import mcafee as m
# >>> mc = m.client('localhost',8443,'ga','ga')
# >>> dir(mc)
# ['__class__', '__delattr__', '__dict__', '__doc__', '__format__', '__getattr__',
# '__getattribute__', '__hash__', '__init__', '__module__', '__new__', '__reduce_
# _', '__reduce_ex__', '__repr__', '__setattr__', '__sizeof__', '__str__', '__subc
# lasshook__', '__weakref__', '_invoker', 'console', 'core', 'help', 'scheduler',
# 'tasklog']
# >>> dir(mc.core)
# ['__doc__', '__getattr__', '__init__', '__module__', '_invoker', '_module', 'cor
# e.addPermSetsForUser', 'core.addUser', 'core.exportPermissionSets', 'core.help',
# 'core.importPermissionSets', 'core.listPermSets', 'core.listUsers', 'core.purge
# AuditLog', 'core.removePermSetsForUser', 'core.removeUser', 'core.updateUser']
# >>> mc.core.addUser('test','password')
# True
# >>>
#
# Keep in mind you'll also see the help function (dir(mc)) which
# is not a feature or prefix that has commands


#
# You can specify either positional or named arguments. Using core.help()
# by specifying the command argument (as below) gives a more detailed 
# description of the command.
# 
# >>> mc.core.help('core.addUser')
# 
# OR
#
# >>> mc.core.help(command='core.addUser')
#


#
# For commands that take file uploads, specify the file name as follows:
#
# >>> mc.core.importPermissionSets('file:///c:/foo.xml')
