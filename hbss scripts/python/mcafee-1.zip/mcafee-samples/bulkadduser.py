# Copyright (C) 2010 McAfee, Inc.  All Rights Reserved.

# This sample script demonstrates processing a file and updating the server with its contents.  It
# also demonstrates reading command-line parameters and how to prompt for user input.
#
# Create non-admin password-authenticated users given a file where each line/record represents a user.
# The format of the file is comma separated with two fields per record: user name and full name.
# Here's a sample file:
#
# gwashington,George Washington
# jadams,John Adams
# tjefferson,Thomas Jefferson
# jmadison,James Madison
# jmonroe,Jame Monroe
# jqadams,JohnQuincy Adams
# ajackson,Andrew Jackson
# mvanburen,Martin VanBuren
# whharrison,WilliamHenry Harrison
# jtyler,John Tyler 
#
# The users in the file are added having a password equal to their username and notes containing
# the text 'POTUS'
#
# To invoke this script pass the servername, the port, the username to run the script as, and 
# the name of the file containing the users as command line arguments:
#
# C:\>python samplebulkadduser.py yourservername 8443 yourusername users.txt
#

import mcafee
import sys

# Verify correct number of arguments are given
if(len(sys.argv) != 5):
    print 'Usage: python samplebulkadduser.py <servername> <port> <username> <filename>'
    sys.exit()

server=sys.argv[1]
port=sys.argv[2]
user=sys.argv[3]
filename = sys.argv[4]

#The following two values are optional and are only included here
#for the sake of example; you can remove them for any production script you write.
isdisabled='false' # value (for every user) to use for disabled
mynotes='POTUS' # value (for every user) to use for notes

# Prompt for the password
print 'Enter password: '
pwd = sys.stdin.readline().strip()

mc = mcafee.client(server,port,user,pwd)

f = open(filename, 'r')
added=0
for user in f.xreadlines():
    part = user.split(',')
    name = part[0]
    fullname = part[1]
    try:
        mc.core.addUser(userName=name,password=name,fullName=fullname,disabled=isdisabled,notes=mynotes)
        added = added + 1
    except Exception, e:
        sys.stderr.write('Error adding user: ' + name + ' due to: ' + str(e) + '\n')
print 'Added %d users' % added