# Copyright (C) 2010 McAfee, Inc.  All Rights Reserved.
#
# This sample script demonstrates deleting any disabled non-admin users.

import mcafee
import sys

mc = mcafee.client('myeposerver','8443','usr','pwd')

users = mc.core.listUsers()

for user in users:
  if user['disabled'] == True and user['admin'] == False:
    try:
      mc.core.removeUser(user['name'])
      print 'Removed disabled user ' + user['name']
    except Exception, e:
      sys.stderr.write('Error removing user ' +  + ' Cause:' + str(e))