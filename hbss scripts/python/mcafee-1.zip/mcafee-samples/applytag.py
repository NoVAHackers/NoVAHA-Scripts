# Copyright (C) 2010 McAfee, Inc.  All Rights Reserved.
#
# This sample script demonstrates iterating through a text file
# listing of systems (systems.txt) and applying a tag.

import mcafee

#initiate connection
mc = mcafee.client('myeposerver','8443','usr','pwd')

#open text file
file = open('systems.txt', 'r')

#iterate through list and assign tags
for line in file:
    mc.system.applyTag(line, "Workstation")