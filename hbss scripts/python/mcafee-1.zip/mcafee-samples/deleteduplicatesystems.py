# Copyright (C) 2010 McAfee, Inc.  All Rights Reserved.
#
# This sample script demonstrates removing duplicate systems.

import mcafee
server = 'myeposerver'
mc = mcafee.client(server,'8443','usr','pwd')

queries = mc.core.listQueries()
query_id = None
query_name = "Duplicate Systems Names"
for query in queries:
  if query['name'] == query_name:
    query_id = str(query['id'])

if query_id == None:
    sys.stderr.write("Unable to find query on server '%s' named: %s" % (server, query_name))
    
duplicate_systems = mc.core.executeQuery(query_id)
for duplicate in duplicate_systems:
  find_results = mc.system.find(duplicate['EPOLeafNode.NodeName'])
  if len(find_results) != 0:
    mc.system.delete(duplicate['EPOLeafNode.NodeName'])
    print "Duplicate system \'" + duplicate['EPOLeafNode.NodeName'] + "\' deleted"